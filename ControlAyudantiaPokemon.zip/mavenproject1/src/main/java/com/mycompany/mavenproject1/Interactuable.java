/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Sala-2-11-PC04
 */
public class Interactuable {
    private int IdObjeto;
    private String nombreObjeto;
    
    //constructores

    public Interactuable(int IdObjeto, String nombreObjeto) {
        this.IdObjeto = IdObjeto;
        this.nombreObjeto = nombreObjeto;
    }

    public Interactuable() {
    }
    
    //get y set

    public int getIdObjeto() {
        return IdObjeto;
    }

    public void setIdObjeto(int IdObjeto) {
        this.IdObjeto = IdObjeto;
    }

    public String getNombreObjeto() {
        return nombreObjeto;
    }

    public void setNombreObjeto(String nombreObjeto) {
        this.nombreObjeto = nombreObjeto;
    }
    
}
