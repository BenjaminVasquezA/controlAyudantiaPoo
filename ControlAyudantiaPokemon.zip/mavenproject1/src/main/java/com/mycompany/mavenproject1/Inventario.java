/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.ArrayList;

/**
 *
 * @author Sala-2-11-PC04
 */
public class Inventario {
    private int cantidad;
    private ArrayList<Interactuable> listaObjetos;
    //constructores

    public Inventario(int cantidad, ArrayList<Interactuable> listaObjetos) {
        this.cantidad = cantidad;
        this.listaObjetos = listaObjetos;
    }

    public Inventario() {
    }
    //get y set

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public ArrayList<Interactuable> getListaObjetos() {
        return listaObjetos;
    }

    public void setListaObjetos(ArrayList<Interactuable> listaObjetos) {
        this.listaObjetos = listaObjetos;
    }
    //metodos
    public void crearObjeto(ArrayList<Interactuable> listaObjeto, String){
        
        System.out.println("Objeto obtenido");
    }
    public void eliminarObjeto(ArrayList<Interactuable> listaObjeto){
        System.out.println("el objeto fue tirado");
    }
    public void modificarObjeto(ArrayList<Interactuable> listaObjeto){
        System.out.println("objeto modificado");
    }
    public void leerObjeto(ArrayList<Interactuable> listaObjeto){
        System.out.println("XD");
    }
}
