/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Sala-2-11-PC04
 */
public class Objeto extends Interactuable{
    private String tipoObjeto;
    //constructores
    public Objeto(String tipoObjeto, int IdObjeto, String nombreObjeto) {
        super(IdObjeto, nombreObjeto);
        this.tipoObjeto = tipoObjeto;
    }

    public Objeto(String tipoObjeto) {
        this.tipoObjeto = tipoObjeto;
    }
    
    public Objeto() {
    }
    //get y set

    public String getTipoObjeto() {
        return tipoObjeto;
    }

    public void setTipoObjeto(String tipoObjeto) {
        this.tipoObjeto = tipoObjeto;
    }
    
    
    
    
}
